import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { Router, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NavbarComponent } from '../../shared/components/navbar/navbar.component';
import { TokenService } from '../../core/services/token.service';
import { UserStateService } from '../../core/services/user-state.service';
import { CatalogueService } from '../../core/services/catalogue.service';
import { QuizService } from '../../core/services/quiz.service';
import { InscriptionService } from '../../core/services/inscription.service';
import { CategorieDTO } from '../../models/categorie.model';
import { ModuleDTO } from '../../models/module.model';
import { CoursDTO } from '../../models/cours.model';
import {
  QuizDTO, TentativeQuizDTO, ResultatReponseDTO, ReponseDTO, QuestionDTO
} from '../../models/quiz.model';

@Component({
  selector: 'app-dashboard-apprenant',
  standalone: true,
  imports: [CommonModule, NavbarComponent, RouterModule, FormsModule],
  templateUrl: './dashboard-apprenant.component.html',
  styleUrls: ['./dashboard-apprenant.component.css']
})
export class DashboardApprenantComponent implements OnInit {

  userName  = '';
  userEmail = '';
  activeSection = 'accueil';

  // ── Stats ────────────────────────────────────────────────────────────────────
  stats = [
    { icon: '📂', value: '–', label: 'Catégories',    color: 'var(--green)',  dim: 'var(--green-dim)'  },
    { icon: '📦', value: '–', label: 'Modules',       color: 'var(--brand)',  dim: 'var(--brand-dim)'  },
    { icon: '📘', value: '–', label: 'Cours publiés', color: 'var(--blue)',   dim: 'var(--blue-dim)'   },
    { icon: '🎯', value: '–', label: 'Quiz dispo',    color: 'var(--purple)', dim: 'var(--purple-dim)' },
  ];

  // ── Catalogue ─────────────────────────────────────────────────────────────────
  categories: CategorieDTO[]       = [];
  modules:    ModuleDTO[]          = [];
  cours:      CoursDTO[]           = [];
  loadingCatalogue                 = false;
  catalogNiveau: 0 | 1 | 2        = 0;
  selectedCat:  CategorieDTO | null = null;
  selectedMod:  ModuleDTO | null    = null;
  catModules:   ModuleDTO[]         = [];
  modCours:     CoursDTO[]          = [];
  loadingModules = false;
  loadingCours   = false;

  // ── Inscriptions ──────────────────────────────────────────────────────────────
  mesInscriptions: any[] = [];
  loadingInscriptions = false;

  // ════════════════════════════════════════════════════════════════════════════
  // ── QUIZ ─────────────────────────────────────────────────────────────────────
  // ════════════════════════════════════════════════════════════════════════════

  // Section quiz : liste des cours inscrits et leurs quiz
  mesCours:         CoursDTO[]  = [];
  coursSelectionne: CoursDTO | null = null;
  quizDuCours:      QuizDTO[]   = [];
  loadingMesCours   = false;
  loadingQuizCours  = false;
  quizErrorMsg      = '';

  // Historique tentatives
  activeQuizTab: 'quiz' | 'historique' = 'quiz';
  mesTentatives:    TentativeQuizDTO[] = [];
  loadingTentatives = false;
  showDetailsTentative = false;
  tentativeDetails: TentativeQuizDTO | null = null;

  // ── Quiz Runner ───────────────────────────────────────────────────────────────
  showQuizRunner    = false;
  quizEnCours:      QuizDTO | null = null;
  questionsActuelles: QuestionDTO[] = [];
  reponsesSaisies:  { [qId: number]: number } = {};
  questionIndex     = 0;
  quizTermine       = false;
  resultats:        TentativeQuizDTO | null = null;
  timerRestant      = 0;
  timerInterval:    any;
  submitting        = false;

  constructor(
    private tokenService:      TokenService,
    private userStateService:  UserStateService,
    private catalogueService:  CatalogueService,
    private quizService:       QuizService,
    private inscriptionService: InscriptionService,
    private router:            Router,
    private cdr:               ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.userName  = this.tokenService.getDisplayName();
    this.userEmail = this.tokenService.getUser()?.email ?? '';
    this.userStateService.user$.subscribe(() => {
      this.userName  = this.userStateService.getDisplayName();
      this.userEmail = this.tokenService.getUser()?.email ?? '';
    });
    this.loadCatalogue();
  }

  // ── Catalogue ─────────────────────────────────────────────────────────────────

  loadCatalogue(): void {
    this.loadingCatalogue = true;
    this.catalogueService.getAllCategories().subscribe({
      next: cats => { this.categories = cats; this.stats[0].value = String(cats.length); this.loadingCatalogue = false; this.cdr.detectChanges(); },
      error: () => { this.loadingCatalogue = false; }
    });
    this.catalogueService.getAllModules().subscribe({
      next: mods => { this.modules = mods; const a = mods.filter(m => m.actif && (!m.statut || m.statut === 'ACTIF')); this.stats[1].value = String(a.length); }
    });
    this.catalogueService.getAllCours().subscribe({
      next: c => { this.cours = c; this.stats[2].value = String(c.filter(x => x.statut === 'PUBLIE').length); }
    });
  }

  selectionnerCategorie(cat: CategorieDTO): void {
    this.selectedCat = cat; this.selectedMod = null; this.catalogNiveau = 1;
    this.loadingModules = true; this.catModules = [];
    this.catalogueService.getModulesByCategorie(cat.id!).subscribe({
      next: m => { this.catModules = m.filter(x => x.actif && (!x.statut || x.statut === 'ACTIF')); this.loadingModules = false; },
      error: () => { this.loadingModules = false; }
    });
  }

  selectionnerModule(mod: ModuleDTO): void {
    this.selectedMod = mod; this.catalogNiveau = 2;
    this.loadingCours = true; this.modCours = [];
    this.catalogueService.getCoursByModule(mod.id!).subscribe({
      next: c => { this.modCours = c.filter(x => x.statut === 'PUBLIE'); this.loadingCours = false; },
      error: () => { this.loadingCours = false; }
    });
  }

  retourCategories(): void { this.catalogNiveau = 0; this.selectedCat = null; this.selectedMod = null; }
  retourModules(): void { this.catalogNiveau = 1; this.selectedMod = null; }

  getModulesCount(catId: number): number {
    return this.modules.filter(m => m.categorieId === catId && m.actif && (!m.statut || m.statut === 'ACTIF')).length;
  }
  getCoursCount(modId: number): number {
    return this.cours.filter(c => c.moduleId === modId && c.statut === 'PUBLIE').length;
  }

  // ════════════ QUIZ ════════════

  ouvrirSectionQuiz(): void {
    this.setSection('quiz');
    this.activeQuizTab = 'quiz';
    this.chargerMesCours();
  }

  chargerMesCours(): void {
    this.loadingMesCours = true;
    this.quizErrorMsg = '';
    // Apprenants voient leurs cours inscrits via getMesCours (inscriptions)
    this.catalogueService.getMesCours().subscribe({
      next: cours => {
        this.mesCours = cours;
        this.loadingMesCours = false;
        // Mettre à jour le stat "Quiz dispo"
        if (cours.length > 0 && !this.coursSelectionne) {
          this.selectionnerCoursQuiz(cours[0]);
        }
        this.cdr.detectChanges();
      },
      error: () => {
        // Fallback : charger tous les cours publiés
        this.catalogueService.getCoursPublies().subscribe({
          next: cours => { this.mesCours = cours; this.loadingMesCours = false; if (cours.length > 0 && !this.coursSelectionne) this.selectionnerCoursQuiz(cours[0]); this.cdr.detectChanges(); },
          error: () => { this.loadingMesCours = false; this.quizErrorMsg = 'Impossible de charger les cours.'; }
        });
      }
    });
  }

  selectionnerCoursQuiz(cours: CoursDTO): void {
    this.coursSelectionne = cours;
    this.loadingQuizCours = true;
    this.quizDuCours = [];
    this.quizService.getQuizDisponiblesParCours(cours.idCours!).subscribe({
      next: quiz => {
        this.quizDuCours = quiz;
        this.stats[3].value = String(quiz.length);
        this.loadingQuizCours = false;
        this.cdr.detectChanges();
      },
      error: () => { this.loadingQuizCours = false; }
    });
  }

  setQuizTab(t: 'quiz' | 'historique'): void {
    this.activeQuizTab = t;
    if (t === 'historique') this.chargerHistorique();
  }

  chargerHistorique(): void {
    this.loadingTentatives = true;
    this.quizService.getMesTentatives().subscribe({
      next: t => { this.mesTentatives = t; this.loadingTentatives = false; this.cdr.detectChanges(); },
      error: () => { this.loadingTentatives = false; }
    });
  }

  voirDetailsTentative(t: TentativeQuizDTO): void {
    this.quizService.getTentativeById(t.id!).subscribe({
      next: d => { this.tentativeDetails = d; this.showDetailsTentative = true; },
      error: () => {}
    });
  }

  fermerDetailsTentative(): void { this.showDetailsTentative = false; this.tentativeDetails = null; }

  // ── Quiz Runner ───────────────────────────────────────────────────────────────

  commencerQuiz(quiz: QuizDTO): void {
    this.quizErrorMsg = '';
    this.quizService.getQuizById(quiz.id!).subscribe({
      next: q => {
        this.quizEnCours   = q;
        this.quizTermine   = false;
        this.resultats     = null;
        this.reponsesSaisies = {};
        this.questionIndex = 0;

        let questions = [...(q.questions ?? [])];
        if (q.config.randomiserQuestions) questions = questions.sort(() => Math.random() - .5);
        if (q.config.randomiserReponses)  questions = questions.map(qu => ({ ...qu, reponses: [...qu.reponses].sort(() => Math.random() - .5) }));
        this.questionsActuelles = questions;
        this.showQuizRunner = true;

        if (q.config.tempsLimiteMinutes) {
          this.timerRestant = q.config.tempsLimiteMinutes * 60;
          this.demarrerTimer();
        } else {
          this.timerRestant = 0;
        }
        this.cdr.detectChanges();
      },
      error: e => { this.quizErrorMsg = e.message; }
    });
  }

  demarrerTimer(): void {
    clearInterval(this.timerInterval);
    this.timerInterval = setInterval(() => {
      this.timerRestant--;
      if (this.timerRestant <= 0) { clearInterval(this.timerInterval); this.soumettrQuiz(); }
      this.cdr.detectChanges();
    }, 1000);
  }

  get timerFormate(): string {
    const m = Math.floor(this.timerRestant / 60);
    const s = this.timerRestant % 60;
    return `${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
  }

  get timerUrgent(): boolean { return this.timerRestant > 0 && this.timerRestant <= 60; }

  get questionCourante(): QuestionDTO { return this.questionsActuelles[this.questionIndex]; }

  get progression(): number {
    if (!this.questionsActuelles.length) return 0;
    return Math.round(Object.keys(this.reponsesSaisies).length / this.questionsActuelles.length * 100);
  }

  selectionnerReponse(questionId: number, reponseId: number): void {
    if (this.quizTermine) return;
    this.reponsesSaisies[questionId] = reponseId;
    if (this.quizEnCours?.config.correctionInstantanee && this.questionIndex < this.questionsActuelles.length - 1) {
      setTimeout(() => { this.questionIndex++; this.cdr.detectChanges(); }, 1200);
    }
    this.cdr.detectChanges();
  }

  reponseSelectionnee(questionId: number, reponseId: number): boolean {
    return this.reponsesSaisies[questionId] === reponseId;
  }

  getStatutReponse(questionId: number, reponseId: number, estCorrecte: boolean): string {
    if (!this.quizEnCours?.config.correctionInstantanee) return '';
    if (this.reponsesSaisies[questionId] !== reponseId) return '';
    return estCorrecte ? 'correcte' : 'incorrecte';
  }

  questionSuivante(): void { if (this.questionIndex < this.questionsActuelles.length - 1) this.questionIndex++; }
  questionPrecedente(): void { if (this.questionIndex > 0) this.questionIndex--; }
  allerQuestion(i: number): void { this.questionIndex = i; }

  soumettrQuiz(): void {
    clearInterval(this.timerInterval);
    if (!this.quizEnCours) return;
    this.submitting = true;
    const dto = {
      quizId: this.quizEnCours.id!,
      reponses: Object.entries(this.reponsesSaisies).map(([qId, rId]) => ({
        questionId: Number(qId), reponseIdSelectionnee: rId
      }))
    };
    this.quizService.soumettreQuiz(dto).subscribe({
      next: res => { this.resultats = res; this.quizTermine = true; this.submitting = false; this.cdr.detectChanges(); },
      error: e => { this.quizErrorMsg = e.message; this.submitting = false; }
    });
  }

  recommencerQuiz(): void { if (this.quizEnCours) this.commencerQuiz(this.quizEnCours); }

  fermerQuiz(): void {
    clearInterval(this.timerInterval);
    this.showQuizRunner = false;
    this.quizEnCours   = null;
    this.quizTermine   = false;
    this.resultats     = null;
    this.reponsesSaisies = {};
    this.questionIndex  = 0;
  }

  get messageScore(): string {
    if (!this.resultats) return '';
    const s = this.resultats.scoreSur20;
    if (s < 10)  return 'Niveau insuffisant, vous devez améliorer votre niveau.';
    if (s <= 15) return 'Niveau assez bien, continuez vos efforts !';
    return `Excellent travail ${this.userName} ! 🎉`;
  }

  get couleurScore(): string {
    if (!this.resultats) return '';
    const s = this.resultats.scoreSur20;
    if (s < 10)  return 'rouge';
    if (s <= 15) return 'orange';
    return 'vert';
  }

  // ── Helpers ───────────────────────────────────────────────────────────────────

  setSection(s: string): void { this.activeSection = s; }
  navigateToProfil(): void    { this.router.navigate(['/profil']); }

  getNiveauCls(n?: string): string {
    if (n === 'DEBUTANT')      return 'b-green';
    if (n === 'INTERMEDIAIRE') return 'b-blue';
    return 'b-red';
  }

  getStatutCoursCls(s?: string): string {
    if (s === 'PUBLIE')  return 'b-green';
    if (s === 'ARCHIVE') return 'b-red';
    return 'b-orange';
  }

  formatDate(d?: string): string {
    if (!d) return '—';
    return new Date(d).toLocaleDateString('fr-FR', { day: '2-digit', month: 'short', year: 'numeric' });
  }
}
