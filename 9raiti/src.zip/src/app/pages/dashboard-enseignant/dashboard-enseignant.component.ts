import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, FormArray, Validators, AbstractControl } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { NavbarComponent } from '../../shared/components/navbar/navbar.component';
import { TokenService } from '../../core/services/token.service';
import { UserStateService } from '../../core/services/user-state.service';
import { CatalogueService } from '../../core/services/catalogue.service';
import { InscriptionService } from '../../core/services/inscription.service';
import { QuizService } from '../../core/services/quiz.service';
import { CategorieDTO } from '../../models/categorie.model';
import { ModuleDTO, StatutModule } from '../../models/module.model';
import { CoursDTO, Niveau, StatutCours } from '../../models/cours.model';
import { ApprenantInscritDTO } from '../../models/apprenant-inscrit.model';
import { QuizDTO, QuestionDTO, ReponseDTO, TypeQuestion } from '../../models/quiz.model';

const ACCEPTED_MIME_TYPES = ['application/pdf','video/mp4','video/webm','video/ogg','video/avi','video/quicktime'];

@Component({
  selector: 'app-dashboard-enseignant',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule, NavbarComponent, DatePipe, RouterModule],
  templateUrl: './dashboard-enseignant.component.html',
  styleUrls: ['./dashboard-enseignant.component.css']
})
export class DashboardEnseignantComponent implements OnInit {

  userName = ''; userEmail = ''; activeSection = 'accueil';
  enseignantConnecteId: number | null = null;

  stats = [
    { icon: '📘', value: '0', label: 'Cours publiés',      color: 'var(--blue)',   dim: 'var(--blue-dim)'   },
    { icon: '🗂',  value: '0', label: 'Catégories',         color: 'var(--green)',  dim: 'var(--green-dim)'  },
    { icon: '📦', value: '0', label: 'Modules',            color: 'var(--brand)',  dim: 'var(--brand-dim)'  },
    { icon: '👥', value: '–', label: 'Étudiants inscrits', color: 'var(--orange)', dim: 'var(--orange-dim)' },
  ];

  categories: CategorieDTO[] = []; modules: ModuleDTO[] = []; cours: CoursDTO[] = [];
  loadingCategories = false; loadingModules = false; loadingCours = false;
  successMsg = ''; errorMsg = '';
  deleteTarget: { type: 'categorie' | 'module' | 'cours'; id: number; name: string } | null = null;

  showCatModal = false; editingCat: CategorieDTO | null = null; catForm!: FormGroup; catLoading = false;
  showModModal = false; editingMod: ModuleDTO | null = null; modForm!: FormGroup; modLoading = false;
  showCoursModal = false; editingCours: CoursDTO | null = null; coursForm!: FormGroup; coursLoading = false;
  selectedFile: File | null = null; uploadingId: number | null = null; uploadLoading = false;
  niveaux: Niveau[] = ['DEBUTANT', 'INTERMEDIAIRE', 'AVANCE'];
  statuts: StatutCours[] = ['BROUILLON', 'PUBLIE', 'ARCHIVE'];

  contenuNiveau: 0 | 1 | 2 = 0;
  contenuCategorieSelectee: CategorieDTO | null = null;
  contenuModuleSelectionne: ModuleDTO | null = null;
  contenuModules: ModuleDTO[] = []; contenuCours: CoursDTO[] = [];
  contenuLoadingModules = false; contenuLoadingCours = false;

  mesApprenants: ApprenantInscritDTO[] = []; apprenantsDuModule: ApprenantInscritDTO[] = [];
  loadingApprenants = false; apprenantError = '';
  moduleSelectionneId: number | null = null; moduleSelectionneNom = ''; apprenantSearch = '';

  // ════════════════════════ QUIZ ════════════════════════
  mesQuiz: QuizDTO[] = []; loadingQuiz = false;
  showQuizModal = false; editingQuiz: QuizDTO | null = null; quizForm!: FormGroup; quizLoading = false;
  showQuestionsModal = false; quizSelectionne: QuizDTO | null = null; questionsLoading = false;
  showQuestionModal = false; editingQuestion: QuestionDTO | null = null; questionForm!: FormGroup; questionLoading = false;
  showDetailsModal = false; quizDetails: QuizDTO | null = null;
  deleteQuizTarget: { type: 'quiz' | 'question'; id: number; nom: string } | null = null;

  constructor(
    private tokenService: TokenService, private userStateService: UserStateService,
    private catalogueService: CatalogueService, private fb: FormBuilder,
    private inscriptionService: InscriptionService, private quizService: QuizService,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.userName = this.tokenService.getDisplayName();
    this.userEmail = this.tokenService.getUser()?.email ?? '';
    this.enseignantConnecteId = this.tokenService.getEnseignantId();
    this.userStateService.user$.subscribe(() => {
      this.userName = this.userStateService.getDisplayName();
      this.userEmail = this.tokenService.getUser()?.email ?? '';
      this.enseignantConnecteId = this.tokenService.getEnseignantId();
    });
    this.buildForms(); this.loadAll(); this.loadMesApprenants();
  }

  private buildForms(): void {
    this.catForm = this.fb.group({ nom: ['', [Validators.required, Validators.minLength(2)]], description: [''] });
    this.modForm = this.fb.group({
      nom: ['', [Validators.required, Validators.minLength(2)]], description: ['', Validators.required],
      code: ['', [Validators.required, Validators.pattern(/^[A-Z]{2,10}-\d+$/)]], actif: [true], statut: ['ACTIF'], categorieId: [null]
    });
    this.coursForm = this.fb.group({
      titre: ['', [Validators.required, Validators.minLength(3)]], description: ['', Validators.required],
      niveau: ['DEBUTANT', Validators.required], statut: ['PUBLIE'], dureeMinutes: [null, [Validators.min(1)]], moduleId: [null, Validators.required]
    });
  }

  loadAll(): void { this.loadCategories(); this.loadModules(); this.loadCours(); }

  loadCategories(): void {
    this.loadingCategories = true;
    this.catalogueService.getAllCategories().subscribe({
      next: d => { this.categories = d; this.stats[1].value = String(d.length); this.loadingCategories = false; this.cdr.detectChanges(); },
      error: e => { this.loadingCategories = false; this.showError(this.extractError(e, 'Impossible de charger les catégories.')); }
    });
  }

  loadModules(): void {
    this.loadingModules = true;
    this.catalogueService.getMesModules().subscribe({
      next: d => { this.modules = d; this.stats[2].value = String(d.length); this.loadingModules = false; this.cdr.detectChanges(); },
      error: e => { this.loadingModules = false; this.showError(this.extractError(e, 'Impossible de charger les modules.')); }
    });
  }

  loadCours(): void {
    this.loadingCours = true;
    this.catalogueService.clearCache();
    this.catalogueService.getMesCours().subscribe({
      next: d => { this.cours = d; this.stats[0].value = String(d.filter(c => c.statut === 'PUBLIE').length); this.loadingCours = false; this.cdr.detectChanges(); },
      error: e => { this.loadingCours = false; this.showError(this.extractError(e, 'Impossible de charger les cours.')); }
    });
  }

  openCreateCat(): void { this.editingCat = null; this.catForm.reset({ nom: '', description: '' }); this.showCatModal = true; }
  openEditCat(cat: CategorieDTO): void { this.editingCat = cat; this.catForm.patchValue({ nom: cat.nom, description: cat.description ?? '' }); this.showCatModal = true; }
  submitCat(): void {
    if (this.catForm.invalid) { this.catForm.markAllAsTouched(); return; }
    this.catLoading = true;
    const obs = this.editingCat?.id ? this.catalogueService.updateCategorie(this.editingCat.id, this.catForm.value) : this.catalogueService.createCategorie(this.catForm.value);
    obs.subscribe({ next: () => { this.catLoading = false; this.showCatModal = false; this.loadCategories(); this.showSuccess(this.editingCat ? 'Catégorie mise à jour.' : 'Catégorie créée.'); }, error: e => { this.catLoading = false; this.showError(this.extractError(e, 'Erreur.')); } });
  }

  openCreateMod(): void { this.editingMod = null; this.modForm.reset({ nom:'',description:'',code:'',actif:true,statut:'ACTIF',categorieId:null }); this.showModModal = true; }
  openEditMod(mod: ModuleDTO): void { this.editingMod = mod; this.modForm.patchValue({ nom:mod.nom,description:mod.description,code:mod.code,actif:mod.actif,statut:mod.statut??(mod.actif?'ACTIF':'BROUILLON'),categorieId:mod.categorieId??null }); this.showModModal = true; }
  submitMod(): void {
    if (this.modForm.invalid) { this.modForm.markAllAsTouched(); return; }
    this.modLoading = true;
    const val = this.modForm.value; const dto: ModuleDTO = { ...val, actif: val.statut === 'ACTIF' };
    const obs = this.editingMod?.id ? this.catalogueService.updateModule(this.editingMod.id, dto) : this.catalogueService.createModule(dto);
    obs.subscribe({ next: () => { this.modLoading = false; this.showModModal = false; this.loadModules(); this.showSuccess(this.editingMod ? 'Module mis à jour.' : 'Module créé.'); }, error: e => { this.modLoading = false; this.showError(this.extractError(e, 'Erreur.')); } });
  }

  openCreateCours(): void { this.editingCours = null; this.coursForm.reset({ titre:'',description:'',niveau:'DEBUTANT',statut:'PUBLIE',dureeMinutes:null,moduleId:null }); this.selectedFile = null; this.showCoursModal = true; }
  openEditCours(c: CoursDTO): void { this.editingCours = c; this.coursForm.patchValue({ titre:c.titre,description:c.description,niveau:c.niveau,statut:c.statut??'BROUILLON',dureeMinutes:c.dureeMinutes??null,moduleId:c.moduleId }); this.selectedFile = null; this.showCoursModal = true; }
  submitCours(): void {
    if (this.coursForm.invalid) { this.coursForm.markAllAsTouched(); return; }
    this.coursLoading = true;
    const dto: CoursDTO = { titre:this.coursForm.value.titre, description:this.coursForm.value.description, niveau:this.coursForm.value.niveau, statut:this.coursForm.value.statut, dureeMinutes:this.coursForm.value.dureeMinutes||undefined, moduleId:Number(this.coursForm.value.moduleId) };
    const obs = this.editingCours?.idCours ? this.catalogueService.updateCours(this.editingCours.idCours, dto) : this.catalogueService.createCours(dto);
    obs.subscribe({ next: created => { this.coursLoading = false; this.showCoursModal = false; if (this.selectedFile && created.idCours) this.uploadFile(created.idCours, this.selectedFile); else this.loadCours(); this.showSuccess(this.editingCours ? 'Cours mis à jour.' : 'Cours créé.'); }, error: e => { this.coursLoading = false; this.showError(this.extractError(e, 'Erreur.')); } });
  }

  onFileSelected(event: Event): void { const f = (event.target as HTMLInputElement).files?.[0]; if (!f) return; if (!ACCEPTED_MIME_TYPES.includes(f.type)) { this.showError(`Type non supporté.`); this.selectedFile = null; return; } this.selectedFile = f; }
  openUpload(cours: CoursDTO): void { const i = document.createElement('input'); i.type='file'; i.accept='application/pdf,video/mp4,video/webm,video/ogg'; i.onchange = e => { const f = (e.target as HTMLInputElement).files?.[0]; if (f && cours.idCours) this.uploadFile(cours.idCours, f); }; i.click(); }
  uploadFile(coursId: number, file: File): void {
    this.uploadLoading = true; this.uploadingId = coursId;
    this.catalogueService.uploadCoursFile(coursId, file).subscribe({ next: () => { this.uploadLoading = false; this.uploadingId = null; this.selectedFile = null; this.loadCours(); this.showSuccess(`Fichier uploadé.`); }, error: e => { this.uploadLoading = false; this.uploadingId = null; this.showError(this.extractError(e, "Erreur upload.")); } });
  }
  getFileIcon(cours: CoursDTO): string { if (!cours.filePath) return ''; const p = cours.filePath.toLowerCase(); if (p.endsWith('.pdf')) return '📄 PDF'; if (p.includes('video')||p.endsWith('.mp4')||p.endsWith('.webm')) return '🎬 Vidéo'; return '📎 Fichier'; }
  getViewUrl(cours: CoursDTO): string { return cours.idCours ? `/cours/${cours.idCours}` : '#'; }

  confirmDelete(type: 'categorie'|'module'|'cours', id: number, name: string): void { this.deleteTarget = { type, id, name }; }
  cancelDelete(): void { this.deleteTarget = null; }
  executeDelete(): void {
    if (!this.deleteTarget) return;
    const { type, id } = this.deleteTarget; this.deleteTarget = null;
    const obs = type==='categorie' ? this.catalogueService.deleteCategorie(id) : type==='module' ? this.catalogueService.deleteModule(id) : this.catalogueService.deleteCours(id);
    obs.subscribe({ next: () => { this.showSuccess(`Supprimé(e).`); if (type==='categorie') this.loadCategories(); else if (type==='module') this.loadModules(); else this.loadCours(); }, error: e => this.showError(this.extractError(e, 'Erreur suppression.')) });
  }

  ouvrirContenu(): void { this.contenuNiveau=0; this.contenuCategorieSelectee=null; this.contenuModuleSelectionne=null; this.setSection('contenu'); if (this.categories.length===0) this.loadCategories(); }
  selectionnerCategorie(cat: CategorieDTO): void { this.contenuCategorieSelectee=cat; this.contenuModuleSelectionne=null; this.contenuNiveau=1; this.contenuLoadingModules=true; this.contenuModules=[]; this.catalogueService.getModulesByCategorie(cat.id!).subscribe({ next: d => { this.contenuModules=d; this.contenuLoadingModules=false; this.cdr.detectChanges(); }, error: () => { this.contenuLoadingModules=false; } }); }
  selectionnerModule(mod: ModuleDTO): void { this.contenuModuleSelectionne=mod; this.contenuNiveau=2; this.contenuLoadingCours=true; this.contenuCours=[]; this.catalogueService.getCoursByModule(mod.id!).subscribe({ next: d => { this.contenuCours=d; this.contenuLoadingCours=false; this.cdr.detectChanges(); }, error: () => { this.contenuLoadingCours=false; } }); }
  contenuRetourCategories(): void { this.contenuNiveau=0; this.contenuCategorieSelectee=null; this.contenuModuleSelectionne=null; }
  contenuRetourModules(): void { this.contenuNiveau=1; this.contenuModuleSelectionne=null; }

  // ════════════ QUIZ ════════════
  ouvrirSectionQuiz(): void { this.setSection('quiz'); this.chargerMesQuiz(); }

  chargerMesQuiz(): void {
    this.loadingQuiz = true;
    this.quizService.getMesQuiz().subscribe({
      next: d => { this.mesQuiz = d; this.loadingQuiz = false; this.cdr.detectChanges(); },
      error: e => { this.loadingQuiz = false; this.showError(this.extractError(e, 'Impossible de charger les quiz.')); }
    });
  }

  buildQuizForm(quiz?: QuizDTO): void {
    this.quizForm = this.fb.group({
      titre:                [quiz?.titre ?? '', [Validators.required, Validators.minLength(3)]],
      description:          [quiz?.description ?? ''],
      coursId:              [quiz?.coursId ?? null, Validators.required],
      actif:                [quiz?.actif ?? true],
      correctionInstantanee:[quiz?.config?.correctionInstantanee ?? false],
      tempsLimiteMinutes:   [quiz?.config?.tempsLimiteMinutes ?? null],
      randomiserQuestions:  [quiz?.config?.randomiserQuestions ?? false],
      randomiserReponses:   [quiz?.config?.randomiserReponses ?? false],
    });
  }

  ouvrirCreerQuiz(): void { this.editingQuiz = null; this.buildQuizForm(); this.showQuizModal = true; }
  ouvrirModifierQuiz(quiz: QuizDTO): void { this.editingQuiz = quiz; this.buildQuizForm(quiz); this.showQuizModal = true; }
  fermerQuizModal(): void { this.showQuizModal = false; this.editingQuiz = null; }

  sauvegarderQuiz(): void {
    if (this.quizForm.invalid) { this.quizForm.markAllAsTouched(); return; }
    const v = this.quizForm.value;
    const dto: QuizDTO = { titre:v.titre, description:v.description, coursId:Number(v.coursId), actif:v.actif, config:{ correctionInstantanee:v.correctionInstantanee, tempsLimiteMinutes:v.tempsLimiteMinutes?Number(v.tempsLimiteMinutes):null, randomiserQuestions:v.randomiserQuestions, randomiserReponses:v.randomiserReponses } };
    this.quizLoading = true;
    const obs = this.editingQuiz?.id ? this.quizService.mettreAJourQuiz(this.editingQuiz.id, dto) : this.quizService.creerQuiz(dto);
    obs.subscribe({ next: () => { this.quizLoading=false; this.fermerQuizModal(); this.chargerMesQuiz(); this.showSuccess(this.editingQuiz?'Quiz modifié.':'Quiz créé.'); }, error: e => { this.quizLoading=false; this.showError(this.extractError(e,'Erreur quiz.')); } });
  }

  ouvrirQuestions(quiz: QuizDTO): void {
    this.questionsLoading = true;
    this.quizService.getQuizById(quiz.id!).subscribe({
      next: q => { this.quizSelectionne=q; this.questionsLoading=false; this.showQuestionsModal=true; },
      error: e => { this.questionsLoading=false; this.showError(this.extractError(e,'Erreur.')); }
    });
  }
  fermerQuestionsModal(): void { this.showQuestionsModal=false; this.quizSelectionne=null; }

  buildQuestionForm(question?: QuestionDTO): void {
    const type = question?.type ?? 'QCM';
    this.questionForm = this.fb.group({
      texte: [question?.texte ?? '', [Validators.required, Validators.minLength(3)]],
      type: [type, Validators.required],
      reponses: this.fb.array(question?.reponses?.length ? question.reponses.map(r => this.creerReponseGroup(r)) : (type==='VRAI_FAUX' ? this.reponsesPourVraiFaux() : [this.creerReponseGroup(), this.creerReponseGroup()]))
    });
    this.onTypeChange(type);
  }

  creerReponseGroup(r?: ReponseDTO): FormGroup {
    return this.fb.group({ id:[r?.id??null], texte:[r?.texte??'', Validators.required], estCorrecte:[r?.estCorrecte??false] });
  }

  reponsesPourVraiFaux(): FormGroup[] {
    return [this.fb.group({id:[null],texte:['Vrai'],estCorrecte:[true]}), this.fb.group({id:[null],texte:['Faux'],estCorrecte:[false]})];
  }

  get reponses(): FormArray { return this.questionForm?.get('reponses') as FormArray; }

  onTypeChange(type: string): void {
    if (!this.questionForm) return;
    if (type === 'VRAI_FAUX') { this.reponses.clear(); this.reponsesPourVraiFaux().forEach(g => this.reponses.push(g)); this.reponses.controls.forEach(c => c.get('texte')?.disable()); }
    else { this.reponses.controls.forEach(c => c.get('texte')?.enable()); }
  }

  ajouterReponse(): void { this.reponses.push(this.creerReponseGroup()); }
  supprimerReponseForm(i: number): void { if (this.reponses.length > 2) this.reponses.removeAt(i); }
  ouvrirAjouterQuestion(): void { this.editingQuestion=null; this.buildQuestionForm(); this.showQuestionModal=true; }
  ouvrirModifierQuestion(q: QuestionDTO): void { this.editingQuestion=q; this.buildQuestionForm(q); this.showQuestionModal=true; }
  fermerQuestionModal(): void { this.showQuestionModal=false; this.editingQuestion=null; }

  sauvegarderQuestion(): void {
    if (this.questionForm.invalid) { this.questionForm.markAllAsTouched(); return; }
    const v = this.questionForm.getRawValue();
    const dto: QuestionDTO = { texte:v.texte, type:v.type as TypeQuestion, reponses:v.reponses };
    this.questionLoading = true;
    const obs = this.editingQuestion?.id ? this.quizService.mettreAJourQuestion(this.editingQuestion.id, dto) : this.quizService.ajouterQuestion(this.quizSelectionne!.id!, dto);
    obs.subscribe({
      next: () => { this.questionLoading=false; this.fermerQuestionModal(); this.showSuccess('Question sauvegardée.'); this.quizService.getQuizById(this.quizSelectionne!.id!).subscribe(q => { this.quizSelectionne=q; this.cdr.detectChanges(); }); this.chargerMesQuiz(); },
      error: e => { this.questionLoading=false; this.showError(this.extractError(e,'Erreur question.')); }
    });
  }

  demanderSuppressionQuiz(quiz: QuizDTO): void { this.deleteQuizTarget={ type:'quiz', id:quiz.id!, nom:quiz.titre }; }
  demanderSuppressionQuestion(q: QuestionDTO): void { this.deleteQuizTarget={ type:'question', id:q.id!, nom:q.texte }; }
  annulerSuppressionQuiz(): void { this.deleteQuizTarget=null; }
  confirmerSuppressionQuiz(): void {
    if (!this.deleteQuizTarget) return;
    const { type, id } = this.deleteQuizTarget;
    const obs = type==='quiz' ? this.quizService.supprimerQuiz(id) : this.quizService.supprimerQuestion(id);
    obs.subscribe({
      next: () => { this.showSuccess(`${type==='quiz'?'Quiz':'Question'} supprimé(e).`); this.deleteQuizTarget=null; if (type==='quiz') { this.chargerMesQuiz(); if (this.quizSelectionne?.id===id) this.fermerQuestionsModal(); } else { this.quizService.getQuizById(this.quizSelectionne!.id!).subscribe(q => { this.quizSelectionne=q; this.cdr.detectChanges(); }); this.chargerMesQuiz(); } },
      error: e => { this.deleteQuizTarget=null; this.showError(this.extractError(e,'Erreur.')); }
    });
  }

  ouvrirDetailsQuiz(quiz: QuizDTO): void { this.quizService.getQuizById(quiz.id!).subscribe({ next: q => { this.quizDetails=q; this.showDetailsModal=true; }, error: e => { this.showError(this.extractError(e,'Erreur.')); } }); }
  fermerDetailsQuiz(): void { this.showDetailsModal=false; this.quizDetails=null; }
  getNomCours(coursId: number): string { return this.cours.find(c => c.idCours === coursId)?.titre ?? `Cours #${coursId}`; }
  getQControl(name: string): AbstractControl { return this.questionForm.get(name)!; }
  getQuizControl(name: string): AbstractControl { return this.quizForm.get(name)!; }

  // ════════════ APPRENANTS ════════════
  loadMesApprenants(): void {
    this.loadingApprenants=true; this.apprenantError='';
    this.inscriptionService.getMesApprenants().subscribe({ next: d => { this.mesApprenants=d; this.loadingApprenants=false; this.cdr.detectChanges(); }, error: e => { this.apprenantError=e.message??'Erreur.'; this.loadingApprenants=false; this.cdr.detectChanges(); } });
  }
  chargerApprenantsDuModule(moduleId: number, moduleNom: string): void { this.moduleSelectionneId=moduleId; this.moduleSelectionneNom=moduleNom; this.apprenantSearch=''; this.loadingApprenants=true; this.apprenantError=''; this.inscriptionService.getApprenantsDuModule(moduleId).subscribe({ next: d => { this.apprenantsDuModule=d; this.loadingApprenants=false; this.cdr.detectChanges(); }, error: e => { this.apprenantError=e.message??'Erreur.'; this.loadingApprenants=false; this.cdr.detectChanges(); } }); }
  fermerDetailApprenants(): void { this.moduleSelectionneId=null; this.moduleSelectionneNom=''; this.apprenantsDuModule=[]; this.apprenantSearch=''; }
  get apprenantsFiltres(): ApprenantInscritDTO[] { const l = this.moduleSelectionneId ? this.apprenantsDuModule : this.mesApprenants; if (!this.apprenantSearch.trim()) return l; const q = this.apprenantSearch.toLowerCase(); return l.filter(a => String(a.apprenantId).includes(q) || a.moduleNom.toLowerCase().includes(q) || a.moduleCode.toLowerCase().includes(q)); }
  getNbApprenantsDuModule(moduleId: number): number { return this.mesApprenants.filter(a => a.moduleId === moduleId).length; }

  // ════════════ HELPERS ════════════
  setSection(s: string): void { this.activeSection = s; }
  getCatName(id?: number): string { if (!id) return '–'; return this.categories.find(c => c.id===id)?.nom ?? '–'; }
  getModName(id?: number): string { if (!id) return '–'; return this.modules.find(m => m.id===id)?.nom ?? this.contenuModules.find(m => m.id===id)?.nom ?? '–'; }
  isMonModule(mod: ModuleDTO): boolean { return this.enseignantConnecteId !== null && mod.enseignantId === this.enseignantConnecteId; }
  isMonCours(c: CoursDTO): boolean { return this.enseignantConnecteId !== null && c.enseignantId === this.enseignantConnecteId; }
  getNiveauColor(n?: Niveau): string { if (n==='DEBUTANT') return 'var(--green)'; if (n==='INTERMEDIAIRE') return 'var(--brand)'; return 'var(--red)'; }
  getNiveauDim(n?: Niveau): string { if (n==='DEBUTANT') return 'var(--green-dim)'; if (n==='INTERMEDIAIRE') return 'var(--brand-dim)'; return 'var(--red-dim)'; }
  getStatutCls(s?: StatutCours): string { if (s==='PUBLIE') return 'b-green'; if (s==='ARCHIVE') return 'b-red'; return 'b-orange'; }
  private showSuccess(msg: string): void { this.successMsg=msg; this.errorMsg=''; setTimeout(()=>{ this.successMsg=''; this.cdr.detectChanges(); }, 4000); }
  private showError(msg: string): void { this.errorMsg=msg; this.successMsg=''; setTimeout(()=>{ this.errorMsg=''; this.cdr.detectChanges(); }, 5000); }
  private extractError(err: any, fallback: string): string { return err?.error?.message ?? err?.error?.error ?? err?.message ?? fallback; }
  get cf() { return this.catForm.controls; }
  get mf() { return this.modForm.controls; }
  get ff() { return this.coursForm.controls; }
  private _colors = [{color:'var(--blue)',dim:'var(--blue-dim)',icon:'💻'},{color:'var(--brand)',dim:'var(--brand-dim)',icon:'🎯'},{color:'var(--green)',dim:'var(--green-dim)',icon:'🔬'},{color:'var(--orange)',dim:'var(--orange-dim)',icon:'📐'},{color:'var(--purple)',dim:'var(--purple-dim)',icon:'🌐'}];
  getCatStyle(i: number) { return this._colors[i%this._colors.length]; }
  getModColor(i: number) { return this._colors[i%this._colors.length]; }
  getModStatutStyle(mod: ModuleDTO): {bg:string;border:string;color:string;label:string} { const s=mod.statut??(mod.actif?'ACTIF':'BROUILLON'); const m: Record<string,any> = {ACTIF:{bg:'var(--green-dim)',border:'var(--green)',color:'var(--green)',label:'✅ ACTIF'},BROUILLON:{bg:'var(--blue-dim)',border:'var(--blue)',color:'var(--blue)',label:'📝 BROUILLON'},ARCHIVE:{bg:'var(--surface-2)',border:'var(--border)',color:'var(--text-3)',label:'📦 ARCHIVÉ'}}; return m[s]??m['BROUILLON']; }
  getCoursStatutStyle(statut?: string): {bg:string;border:string;color:string;label:string} { const m: Record<string,any> = {PUBLIE:{bg:'var(--green-dim)',border:'var(--green)',color:'var(--green)',label:'🟢 Publié'},BROUILLON:{bg:'var(--blue-dim)',border:'var(--blue)',color:'var(--blue)',label:'📝 Brouillon'},ARCHIVE:{bg:'var(--surface-2)',border:'var(--border)',color:'var(--text-3)',label:'📦 Archivé'}}; return m[statut??'']??m['BROUILLON']; }
  getNiveauStyle(n?: string): {bg:string;color:string;label:string} { const m: Record<string,any> = {DEBUTANT:{bg:'var(--green-dim)',color:'var(--green)',label:'🟢 Débutant'},INTERMEDIAIRE:{bg:'var(--orange-dim)',color:'var(--orange)',label:'🟡 Intermédiaire'},AVANCE:{bg:'var(--red-dim)',color:'var(--red)',label:'🔴 Avancé'}}; return m[n??'']??m['DEBUTANT']; }
  formatDureeEns(min?: number): string { if (!min) return '—'; const h=Math.floor(min/60),m=min%60; return h>0?(m>0?`${h}h ${m}min`:`${h}h`):`${min} min`; }
  formatDateEns(d?: string): string { if (!d) return '—'; return new Date(d).toLocaleDateString('fr-FR',{day:'2-digit',month:'short',year:'numeric'}); }
  isPdf(filePath?: string): boolean { return !!filePath && filePath.toLowerCase().endsWith('.pdf'); }
}
